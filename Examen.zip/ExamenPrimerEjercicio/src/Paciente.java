
public class Paciente {
    String nombre;
    int estadia;
    int cedula;
    
}
