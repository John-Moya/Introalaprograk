package com.sc202.parte3exam;

public class paciente {
    
    String nombre;
    int estadia;
    int cedula;
    
}
