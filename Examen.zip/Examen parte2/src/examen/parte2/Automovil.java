package examen.parte2;
public class Automovil {
    int placa;
    String dueno;
    int precio;
     
}
