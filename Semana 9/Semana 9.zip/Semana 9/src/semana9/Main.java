package semana9;
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        int opcion;

        do{
            opcion=Integer.parseInt(JOptionPane.showInputDialog(null, " Elija la opci\u00f3n que desee\n" + "1.- Comprar Vehiculo\n" + "2.- Comprar accesorios\n" + "3.- Mantenimiento\n" + "4.- Salir\n" + "Ingrese una opcion","Menu Principal",JOptionPane.QUESTION_MESSAGE));
            switch (opcion){
                case 1:comprar_vehi();break;
                case 2:comprar_acceso();break;
                case 3:mantenimiento();break;
                case 4: JOptionPane.showMessageDialog(null,"Que tenga buen dia"); System.exit(0);break;
                default:JOptionPane.showMessageDialog(null, "Elija una opcion valida\n", "Error",JOptionPane.WARNING_MESSAGE);
            }}while(opcion!=4);

        public static void comprar_vehi(){

            Object [] marcas ={"Toyota","Hyundai","Chevrolet","Haval","Nissan"};
            Object opcion = JOptionPane.showInputDialog(null,"Selecciona una marca", "Elegir",JOptionPane.QUESTION_MESSAGE,null,marcas, marcas[0]);


            Object [] año ={"2015","2016","2017","2018","2019","2020","2021"};
            Object opcion2 = JOptionPane.showInputDialog(null,"Selecciona una modelo", "Elegir",JOptionPane.QUESTION_MESSAGE,null,año, año[0]);


            Object [] color ={"Negro","Azul","Blanco"};
            Object opcion3 = JOptionPane.showInputDialog(null,"Selecciona una marca", "Elegir",JOptionPane.QUESTION_MESSAGE,null,color, color[0]);



        }

        public static void comprar_acceso(){

        }
        public static void mantenimiento(){

        }
    }

}
