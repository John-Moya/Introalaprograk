 
public class Doctor {
    String nombre;
    String especialidad;
    int numero;
    
    
}
