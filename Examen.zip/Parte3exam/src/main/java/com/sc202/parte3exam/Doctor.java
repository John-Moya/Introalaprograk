package com.sc202.parte3exam;

public class Doctor {
   String nombre;
   String especialidad;
   int numero;
}
