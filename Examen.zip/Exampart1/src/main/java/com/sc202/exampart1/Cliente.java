package com.sc202.exampart1;

public class Cliente {
    String nombre;
}
