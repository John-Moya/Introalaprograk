package com.sc202.exampart1;

public class caractVidrio {
   
    String tamano;
    String grosor;
    String precio;
}
